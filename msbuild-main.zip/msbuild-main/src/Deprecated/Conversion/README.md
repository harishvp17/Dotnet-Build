# Microsoft.Build.Conversion.Core

⚠️ This package is **deprecated** and should not be referenced. It will be removed in a future version of MSBuild.

Contains `Microsoft.Build.Conversion.Core.dll`, which is provided with MSBuild for compatibility purposes.
