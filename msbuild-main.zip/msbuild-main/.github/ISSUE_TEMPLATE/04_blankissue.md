---
name: 📄 Blank Issue
about: Doesn't fit the other categories? File a blank ticket here.
title: ''
labels: needs-triage
---