[Build Target Map](https://raw.githubusercontent.com/KirillOsenkov/MSBuildStructuredLog/main/docs/BuildTargets.png)
![Build Target Map](https://raw.githubusercontent.com/KirillOsenkov/MSBuildStructuredLog/main/docs/BuildTargets.png)
[Compile Target Map](https://raw.githubusercontent.com/KirillOsenkov/MSBuildStructuredLog/main/docs/CompileTargets.png)
![Compile Target Map](https://raw.githubusercontent.com/KirillOsenkov/MSBuildStructuredLog/main/docs/CompileTargets.png)