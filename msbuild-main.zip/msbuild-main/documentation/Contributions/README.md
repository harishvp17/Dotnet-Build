# Contributed documentation

This directory has documentation that was contributed by developers or users that hasn't been fully vetted for accuracy and correctness.

Explanations in this folder may be slightly or subtly wrong, but can still be very informative for developing an understanding of MSBuild or a specific problem.
